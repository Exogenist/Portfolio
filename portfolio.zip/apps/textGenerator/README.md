### Description
Text generator that uses lorem ipsum style syntax.

### Author
Swainson Holness
Website: [swainsonholness.me](http://swainsonholness.me/)

### Contact
1. email: swainson.holness@ gmail.com 
2. FCC profile: https://www.freecodecamp.com/exogenist

### License
MIT

